#include <list>
#include <vector>
#include <pthread.h>
#include <cstring>
#include <cmath>
#include <jni.h>
#include <unistd.h>
#include <fstream>
#include <iostream>
#include <dlfcn.h>
#include "Tools/Includes/Logger.h"
#include "Tools/Includes/obfuscate.h"
#include "Tools/Includes/Utils.h"
#include "Tools/SOCKET/client.h"
#include "Tools/SOCKET/IncludeClient.h"
#include "Widgets/ImportWidgets.h"
#include "Tools/DrawTools/Draw.h"

extern "C" bool ngSessionActive(void);

static JavaVM* gJvm = nullptr;
static jobject gAppContext = nullptr;
// ===========================================================================
// KeyAuth Configuration
// Change your KeyAuth details here instead of Java for security!
// ===========================================================================
#define KEYAUTH_BASE_URL    OBFUSCATE("https://keyauth-manager.online/api/1.3/")
#define KEYAUTH_APP_NAME    OBFUSCATE("AIMKILL PVT")
#define KEYAUTH_OWNER_ID    OBFUSCATE("6233814381")
#define KEYAUTH_APP_SECRET  OBFUSCATE("5081919537e969d130fc67513875e6341849f55022c539e26dfd5f4a78afa177")
#define KEYAUTH_VERSION     OBFUSCATE("1.0")

extern "C"
JNIEXPORT jstring JNICALL
Java_com_kanishkcheat_Login_getCloudAuthString(JNIEnv *env, jclass clazz, jint key) {
    switch (key) {
        case 0:
            return env->NewStringUTF(KEYAUTH_BASE_URL);
        case 1:
            return env->NewStringUTF(KEYAUTH_APP_NAME);
        case 2:
            return env->NewStringUTF(KEYAUTH_OWNER_ID);
        case 3:
            return env->NewStringUTF(KEYAUTH_APP_SECRET);
        case 4:
            return env->NewStringUTF(KEYAUTH_VERSION);
        default:
            return env->NewStringUTF("");
    }
}

extern "C"
JNIEXPORT jstring JNICALL
Java_com_kanishkcheat_Menu_imageBase64(JNIEnv *env, jclass thiz) {
    return env->NewStringUTF(OBFUSCATE("/9j/4AAQSkZJRgABAQEASABIAAD/4gHYSUNDX1BST0ZJTEUAAQEAAAHIAAAAAAQwAABtbnRyUkdCIFhZWiAH4AABAAEAAAAAAABhY3NwAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAQAA9tYAAQAAAADTLQAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAlkZXNjAAAA8AAAACRyWFlaAAABFAAAABRnWFlaAAABKAAAABRiWFlaAAABPAAAABR3dHB0AAABUAAAABRyVFJDAAABZAAAAChnVFJDAAABZAAAAChiVFJDAAABZAAAAChjcHJ0AAABjAAAADxtbHVjAAAAAAAAAAEAAAAMZW5VUwAAAAgAAAAcAHMAUgBHAEJYWVogAAAAAAAAb6IAADj1AAADkFhZWiAAAAAAAABimQAAt4UAABjaWFlaIAAAAAAAACSgAAAPhAAAts9YWVogAAAAAAAA9tYAAQAAAADTLXBhcmEAAAAAAAQAAAACZmYAAPKnAAANWQAAE9AAAApbAAAAAAAAAABtbHVjAAAAAAAAAAEAAAAMZW5VUwAAACAAAAAcAEcAbwBvAGcAbABlACAASQBuAGMALgAgADIAMAAxADb/2wBDAA0JCgsKCA0LCgsODg0PEyAVExISEyccHhcgLikxMC4pLSwzOko+MzZGNywtQFdBRkxOUlNSMj5aYVpQYEpRUk//2wBDAQ4ODhMREyYVFSZPNS01T09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT0//wAARCAK8Ag0DASIAAhEBAxEB/8QAGwABAAIDAQEAAAAAAAAAAAAAAAIDAQQFBgf/xAA3EAACAgEDAwMCBAUDBQEBAQAAAQIDEQQSIQUxQRMiUQaRFDJTYRUjUnGBFjRyJDNCkqFD8DX/xAAYAQEBAQEBAAAAAAAAAAAAAAAAAQIDBP/EACERAQEBAAIDAQEBAQEBAAAAAAABEQIhAxIxQVETYUJx/9oADAMBAAIRAxEAPwD6UAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAABlfJjK+QMgg7YLvJElKL7NAZBGU4x7ySK56mqHeS+40xcDUfUKF3f8A9KbOq0x7SRPaL610QcmPWam+WjYXU6Gu49oetbwOZb1emHaSKv43V/Uie0X1rsA5H8aq/qRfX1WiS/Mh7Q9a6ANNdRof/kvuTjraZPG5fcuxMrZBWr6v60PWr/rRdRYDClFrKaGUBkAAAAAAAAAAAAAAAAAAAAAAAAAAAABC2CsqlBtpSWODQpus0Vvoaht1v8svg6RVfRC+twmv7P4AtTTWV2BzaLrNFb6Go5rf5ZfB0U01ldgMlGq1MNPXl8yfZfI1Wphp68vmT7I1tLpp3WfidTy3zGLAloqrZ2vU3t5kvbH9jeAAAAAAAAAAA1tRrKqItykjha76iUG1Xn/BLZFnG16Rziu8kYdtcVlyR4G7repnNtS4KZ9W1Mo4c2Z/0jc8Ve4t6pp63jcmV/xmj5R4OOpk3mbbNiNsZLuYvkdJ4Xs/41R8ox/G9P8AKPGTl8NlPLfdk/1p/jHuf43RjwczU9VcdQ7tPN5fdHAqizZhEz/tVnhjq/xe2zlcD+J29ss5jg4PdH7Eoyi1kl537FnCfK3Jay5vO9k4dRuguXk0dxXKxze1cIk5WreMjbv19+pe3c1FEJaixpJyfH7lajiPAX7i8tJxxGU5yfLZlZ8snuSWMFcpfBF6HkjufyzClzySayiKrm2/JBRec5LcKPcynBoKr5ZhucVw2i5JeDMo5XYJ011ZZn8zLY22ReVJ/cjt5GMDsyL1rL0vzsw9fev/ADZR3K5RY9qnrHSq6tfGOHJs2Kes2xfuyziJ4Jbzc51m8JXqaetxk/cbF2rp1dWxT2yXK5PIxmyanKLyng3PJWb4o9bodem/QveJrs35Ogmn2Z4daibXMnu8M3NN1q6rELXnHk3PJK53x2PWg41PW65Jbnguu6tW4KFHNkuP7G5ylYvGxfrNX6X8qr3Wv48EtFp5UwcrJNzny/2I6HSqv+bY91suc/BuFQAAAAAAAAAAAAAAAAAAAAAVX0QvrcJr+z+CrRVX0xnXY1KK/IT1Wphp68vmT7IhovXlGVl8vz/lXwBXTo5zvd2qak88RN450NTbpr3Vqm5QfaR0E01lPKAyAAAAAAAAcnqvU40xcK37ja6jqo6bTybeHg8Nq77b9RKzL78GOXLG+HHat1Opvubc5PBoz5byWOU8clUzjba9M4yNaySTKpXRS5ZXrLNhzZ3uXBkb89Wl2ZOnVN+Tn0wc+5v6fTcoNR0KrHI2YQzyV0VKKNmCMWtLIxwXQjkqWck1JpEROTwU7fdmIbbZiMm37exrjrPLEpwk+PBBwknwTnKaxJdjMZ7hdwmar3TwR9SeeUy/siKWZciRWE5NBtk5R+GFW8FRWm08tE3amvgltb7mPRyyit8slGvJeqPaWV1rsxiahXWvgudS2l8akYaw8DDWlOrHgqccdzoSSKLa0xhrWlHCyiOMo2NqccFbikTBrOPJCUWmXz47EJPcBW2tghP5IzRDHwUXObXYcyXPcqimu5ZnAiXEvckSqtnVLdGTyYy9uCKfhl7/AA6/Xa0nWbK8KbyjtaXqlV6WZLLPGZx2MwtlB7k2jXHyWfWOXjl+PoKnGSymiR4qjq91bSzlI62m69F/nOs5yuV8djvg0qepUWpe5ZNuM4yWYvJvWMSAAAAAAAAAAAAACjVamGnry+ZPtH5LLZOFUpRjuaWUvk0tNpZ22/iNVy/EWA0umndZ+I1PLfMYs6AAFd9ML63Ca/s/g0aLrNFb6Go5rf5ZfB0iq+iF9bhNf2fwBYmmsrlMyaOjV9Fr09icq+8ZfBvAACMpxj+ZpASK7rY1VuUn2NPU9Vop/wDJNnnuo9Wt1EnCviJnlykb48LyVdY6lLUWuCeYpmjBZJ16Wdj3NG3DStI81uvVx440ZQ4KJpLJv3wcVyjTsimmw042uhvzhHLdLUj0FsEzTnQshmqNLX8nV09awijT6fBvQhtSM2rFq4RndgjyZil5MNLYy4JqWVyQTXhGHnOPBqTWbcSb3PC7DtwgmsYRJGrUkSTe3lFcva8xLHP2YSK64ycuewnRZqcbFJcE4xcvBF1qD3R/yi7csLHAv/CVW65RfJbGccYZTOeXhyIOS+QNiUl4K/xCi8NFW7HklmMlyUXPU4xjsX5TgpxOXZPb/ZFmm1EpranwVl04XMlK2L8nPjc1JxZZQnY2akTW1ndyiqVngshBrKZVZU08jE1W2Qcic5JcFUseCWLKw2nwVS9rMSbTG7PcmGoz5RXGPJfhNEWsdhi6h2ZOMeeTEY8luC/8SdovBFpPsT2ruyLx4ItRz4Y5JKDkXV0ya5XYZ+kv41nFoinJeTclVjuUThhmWkY32QeYyaOnoetWUtKbbSOW48EP7CcuUS8ZXu9F1KrUxXuWTeTz2PnlGpsoknGTPT9J6vGyKha+T0cPJK4c/HY7oIwnGazF5JHRyAAAAAAAAAAAAAAAAACM5KEXKTwkBra/WQ0lLnJrJ5DV9bu1FjUHhFv1R1OFknXCR57SSc7P2OXPm7+Px726WbLXuk2yUYtS5Nimv2rgsdOV2OO69M4429FKEoJPBtuMVE4sJumXc3Fqd0e4LFev27Xg4F9+2TWTp667FbeTzl92+bDK+VybMxakzUTbZv6er25ZKNiiKwXNccFMOCUpPHBhU1ySSRQnInBtsDYiiM3glh4G3K5KiEXllmX4MRrWS6O1AYSaXJGVqj2I32LGEzm6nUqpN5LFbs9Uo8tmjqOqRjlKRwtX1CbbxLg51mp3eWdJw1zvJ3J9Vm5PDZKvqljfKbODXdniXY3IurYmrcM16M+z0FOu3Y3ZTNmN+X3OBF2+kpLEkWUa33KLeGLxWcncnJSQ01irsRpwtbWS2Dy8mV+ulbbCOWsZZs6GWY5RyJNvGTa0t+zjJqJXc9PEN7ZRfLMePBVHUSsio54Fr9uF3DLWkm3lkc+EWze2HJXGOHlkVBxfchgusml2Ndz9wVOL5wZeEVqXJJsgypckkynPJne4sDYjHPcyq0mV12NvJtVQc/cVNTrqjlGyoJLBiEYpZ8mJNg1XZFGtOKb7G24tohGrMiYutCyD8I13Fp4Z3J6dJcmjqNPjLSJi657e0lC2UXmMsEbIPJVna+TOY19eh6X1qdTULW8HqtNqIaitSiz5sreeDv8AQupelYq7JcM78Of44+Th+x7AEa5xsgpReUSOrgAAAAAAAAAAAAAB5z6j6lKmDqrfL4PQze2Db+DxHWJqzVt57GOdyN+ObXAuqsum5zfLNnQ0bJcljaz2JQmovJ5vr2Tp2qIrYjM+O5pUatJLkulqFPyFtU6rHdGvG7asZLbppxZyL7ZKbSKzas19+6LSZx0pObNxqc3yuCUKVkiRXTU2dGtbYpEaoKK7E28GbWmG0mZ57lfdkot5MqtjHcuESjDDMRm1xjBZCabwyotgsomoolBwwSePBRGMEUaiW3sW22bI5OXqdTy+SwVarUqKeWcHX65y9qZdq1bdbtjnk09XoJVNbu504xi1oe+bZbDTt9zZqp2rsW4+DpLjlVENOvgzLT5WcG9RVvaRu1aJTmoGozXGpnbQ8ZzH4NuVCsqV9T5XdGxr9C9NLHfJz42yrlsi8J9y2ErqaG1zhiXdG4pbWc/T1zqkpPtI2bZPucrHXi23YnEjXNuZrwn+5bVPbPLRlXc0a9mZF0rI847mhTqW/alwbEVukv3KzUsb1mXYxjx4NmVW2vBTGKw+QNSxPLRVKDNyxKK7GrOWAqO1pZJYbIbycJ5ZFZhDM8F064rCkVOW2aaLcueHIJUoRUHwjYpljOOxBtRS4JVx4f7mmF9ct3Yu2rGGU0JRT+SccyeQLVV2LoQgnnyYi1sz8Gs7cSbyFW6jLTZRHEo4fJr6zWNJpdjnx1+3KyRqNnV11xba7nNsjllstSrJcvJCTy+EZrUa7hjsTqslCSeexJweCKW18ojT13QOp7oqu18no001lHzSm6VU1KDw0ey6J1L8RUoTfuO3DnvTzeThncdoAHVyAAAAAAAAAABqdRt9LTSf7HhNVep2ylnuz2fXFJ6OTj8Hzic5+o0++Tl5HbxNid6TwVO7PYr2t90PTa8HF6NWRtknwze08pvnDNOmttptHe0cK/S5SyEtc29zb4TI16VzeZI7M6apPwRcIQ+BajlWVRiuxr7Peb+qlHOEab7kvxZ9ZXCM+DCGTm2ilyZUoxMtLHLKmsvuMCybb4M1SaeWyueIoodmCxHVjfGPdlj1ccdzietLJF2TlwikdLVatS9qZp2V5W4xVU+8uSVsnFYRZVqzQqr1lvSOb1ezdrJJdkXyscfdHuczVWOdzbOsrnyYzwQU0pLIfya9ksM0xfj2XTOn6W3ps75WpTS4Rz9HcrdX6W/DTxk4ENffXBwjNqPwVw1VkLN8XiXybjlyr1n1Dpp0adWRtjJ4+TyMrHKWXwyd2v1FyassbRr1xlbLCNWpxdrRXW2RjlcI6t1cfSTyaOhqdVKTNmcnJKKOdduMRhHk2dqUYto14xkmbLy4LJhqtmmyEUsLk3tNZveexo6WuL8HRqqw+CM1fKUpLGSpwcS/03t4IxWH7ijXl7uGUzjDDyX2yjuaiad2W+GFVd28EknknCG1ZaMzaXYisqG5FkIy7IxVnHJs1YXdhGKU5LEu5sRj7f3MbVnMWi6EPZkrKEYTUc44FtqhXnszYrug4uDOZ1GyMcpMCF/UnXBqLNR65z89zm3ajLayVxsyyq6Gp1W6OEaKbfkNtmYxwsslaTpTUuTc/c50tTCHdlUuqQUsZMrrr+5rhEJRfO5Gtpuowa5kjcV9d0eGhJ2lvTXUueDodM1ktNfGWcI0pxinmJhPkzOq1mx9K0WojqaIyi/BsHlfprX/AP5SZ6pcnrl2PJymXAAFZAAAAAAAAa3UIb9JOOM8HzbUV7NZOMljk+oyipRafk8P9TaJU3+qkY5zp08dyuXCEWXRoUuyOfXqYxlhs3KtbFywmcHoblelxzgvj7eEUPVJQ5ZTHVLeVG7OUl2NS++fyX+rGUcmjqJ5fBzrUV790uTGcsjHh5ZlPkm9E+ppGUjMeRNYJI1qq1kFjaTffsQknjguJqi1N9ihpruXTbT4MbZSXKCqDY09e7lmPTx3RtVRSh7e4ViXt4Nax5fJfZGb5wadrafJYqq2e00bYOUso3Jx3IhCKT5NysWNN1z29jXnDEuUd+Dr24aRRbRVN9jcrFjivZjsVSS8HYlooS5SMw6fDPY1rneDjVVStlhI6+g0aqalJcm7TpIQXCLo1PwiXks4YhJN9jd0+mTpc5PkodUsGzTv2bX2Ma6SKVBtsu2e1FsKnnsbNellLusIQrGiqzJHVVW2JTptMq2m5r7nQxBwxvj9wzaoUvYUWR3MtxieHJY/uHHL75RSOfbFRZSo88m/fX8I1ZQflEVVbPtFIzXXvaeOCFnfGDZoeK8E0YmlGPBmuOYZbKbG8vDJ1ywuQi+nc54NlTlFYK9M4SfD5Nt0prhl1McrVWOuTcWcfW6pt8s6/UobU8nnNUssGKbJrGUQjbghNPBVzkquhVamhqNXCqD5NNz2V5Rzr/VulwmzcjNrGq1rsk8Go7W33Zf+CufeEvsS/AzS5hLP9jXqz7NeOonHtJnW6TrZ5mpNtJI5k9JZ4hL7FmimtNK1XZjmPGUPVPZ6fRauGpjjPJt42nkunXWVzTjGWG/g9PVa7Kk8M48uLtxrf6fe6dXFp4WT6DpLFbp4yz4PmcJYknye3+nNYrdMoNrP9zp465eWO4ADq4gAAAAAAABwfqehWaSTx2WTvGj1aCnpJJrwS/Fn18k1bdVrI1arY92To9X069SWF5ODZFpNHnenXU/iW5cslX1Bynjg8/OU4vuy7S2SU+WUmV7LSzVkFklbB+DV6XPdBG/OSwc7a36xoPc3hkstcGc5kYa9xn80/cW1cvBdOCWDXre1m3GW7HBZaWRCNLl4I26bbE3q4SaJOpY5KnxwpUyUuxlQcTqW1xXg0rItyeCNKXh90WwiksozGlvwWqO1YCqLZtRxg5d0nv8AcjqXppZwaF0N4VTlOJXty+CxVtLASwypVLTRlKWS/ZnwX01wf5jUqYqqrbXJfCCT5JWShXxFkIuU5ZQ1MbHpxihFYXA2Sa5ZdCKjHsTTEYJN8m5VXCS4TM6aiNjzI3YQhB4gi7UyK69NDKzk2IbJuVbWEi2MM8sorS9ew1GKn+Hrk+Gya00I93L7mY8MTm8YQ2mRXbRDumzNUVGOEZScicY4JasiE0UzSa5RtT7FDSfcza3GhZWk84K3PHBu218cGpKrkzoiopvOS+MVJJMpUGjYhKKXuRdTGfS2PMGbNFrUfcUqazwuDCm2+Fg1Eqeqr/ELCPOa7TqE2menhnsjldT0FjbsUslI87ZDjCNGzMXydO2uUXho0dVW0slSq4KV/EFwbmm0limmlyjb+lNLXfqfTtxh/J0OrqrRa5VVtYOscuTTlp7Yw3NL7GhddZF8JfY9JRRZqdFOblGKS4OFq6lVROVmM+DTDnvV2LxH7FF2netbk5JOMfCIOcXHdk2dBLc7P7EVza9ffTivEWo8djv9O1k7a/djJ5zUwxY2jqdH3NHPk68Y7fqv9j0P0tNT1Kcs5T4PNSTR2fpvUelrYpk4Xtec6fQwRhLdBS+USO7zAAAAAAAABo9We3RSZvHN669vTpslWfXg9alZuf7nn9RViTOrXc5zsi/k19VU1ng4a9P449laIQhiRs2RwyGORpHd6PL24Ojamjk9KlhnUk22c+TcVJe4xJ9yXkhLuT/yT6xH8x1NNBbU2aFMMy7HW08MRXAi1fU4JcmbGse0JY8Ftai+5WWhOpyfJRKpI6V8VHO00Jyk3hoiq9skuCie9Pk3q6nJGJ0Jx57hWhNOUcmhZCW7Pg3b3Kt4fY15Xxw8hVSjuWPJj0uSKnmWUS389wrDjtWTWlqG5bYm3DTW6iWF+U6mk6RTUt0lllg5NVM5rMkblVSS7HTr0inPEVwbMtEopYjyaZ1yoRTNqEYJLgselxLO0n6TXG0mM6shXFQylglB4YjlRwwljsXWW1GWTWqSeosJ72ka9cpetMsqVu4SjkplJN8D1cLDRKEIzWV3I0irHAfiHLsWrTSfglHStPsQVqWVyQxmRsOhpFE4uDySxqMyr9pq2QwWvUPsZbyuxnFakVzyWKGfBsqqMlklXUlIuJqlVJLsEsM6Koi1wa1+mkuYm4zVaaSwiu1KSw2Qk5Q/MRjLcyjnazR5y0jkaurbDDR6myOVycbXVrc8oi45Whst01m+HBq9V1N9t2+TbZ1oQhtxg1NZp96eEdJWLxcp9Y1ca1CNjUV4K59SttplXY8kL6HXJ5XBqzcU+DpK5WYw5PKwzqdLeXZ/Y5PdnU6V3s/4kpii2G+R0+lw2M56/P8A5OrosJo5114t6zuS0Fsq9XBp+TNkdyTRXRiOphn5Mz61y+PqHTrHZpISfwbRodHkpaCGH4N89LyUAAAAAAAAOF9V6j0enTX7HdPL/Wj/AOif9iX4vH6+fae9q9vw2dSSjbDJw4vEso6GkvzwzzPVirUULl4NKUcSO5bBThk5d1eGUjZ6bL3HZfY89o5uFyR3lLMEY5NRXY8FaeWZtaI1/mRlp1NFQ5rODq10uESnpmFBcG9dbGMSxmtWSkVOUoslO7JjdFrIMZjJvuYlBPkeOAm/AEoYSwyqc1F4ayixqWOSqUcouGtHVVb8tHHt09rm9q4PQWJJcmjZXY21X5BrjpTjLbjk6Wj6bK1qc00je0HS25b7I5Owq4xioxjjAkLWpptEoLhF1lE+0TYqcYz2tm24rhrk1Iz7NHSaecOZcF+ybl8l3pyn24L69O492aZ1GFEXDMksmtbWn2RvT9kSqEPUYGgtNOcsY4NuvQcdjerqUfBelgzia5k9BFI1paPGdseWdxxTIOtfBTXFjon3aJRoe/hYOwoLHYwq4p9gapqqUYLK5J7YvwWSjxwU4aYWVTfBeDm6leDpXSaRo2wcnnBlqVzvTeTaqqyTVK7uSRJSrg/zoQ1L0HjsQlFxfY2K9VV2ckXfyrFw0VGlG2USxXt8SROyiOcpGY0r4IrS11G6O6KOfXlPDPQyrUo4Zx9VV6dnC4Ark+DR1dSlBs3e5qaqTUXwUcle1k5rdEhJckXZteGNaamqojNNNHG1Ok25wegscZRyjnahpcs6SsXi4vpyXhmxQ5w/K2srDN2v0pLlLJmUYLshqYrrrTeTdo9uDVh34L921IzVkdSFmayuXEtyNeq3gt3Z4E+rX0T6Ys36KKznCO4eJ+kdbts9KcuD23c7x5bOwAFQAAAAADxv1xe1Rt/weyPH/W9Cen3f5M8vjXD6+ex7lsJ7XwU55Jcnnet1dPcpww3yU6iPc1aZuEk8m+sWV58hHOeYTTO5pZb9Mn5ORbDk6XTnmppkqxKa5wTqityE17idKzI5tO1oZ7YcGxY4y7mrpFiJdPBpmoWKOODX5Rm2TT4K4uTfPYg3KZKUcFii1yjWhLD4NhWYRqCcm2uSnft79jMrUQlJNYKiq+cJvjuZ01SbyFplKWcm1VXGKxkFbNVirjjgjdfBw47mpfaod5GtHUKU8Jlia6Gmp3z3tnUjDCRztFOKeZHQeoj4NsrtySCnLwa9djnLBtwhgyKpLe+S+qtRRFpZLIPgCaZLJAxnARbkMhFkslTDADZByAk2sFU7IrOXgq1Fyrg3k8l1frNiscK5Ga1I7ut6jTVnMlk4ep63KTar7HCnddc8zkzMVgjUjdlr9ROX5mkRdtsuXNlCeENzLgvV1iedzNmnqN1bXuyjnOTRjeXEen03WE0lYb8NfTNfmR4n1Wn3LK9TJdpMYa9t68Jr2yRVqafVhwss8tDWWxeVJm9perzhJKx8ExXQWkmvBoa2tpPg7+j1VWpiuVkjr9FGyD2oDyUa4yg/k5urjjJ2bKVRZJHM11e6Dx3CtCE/a+TU1MlyR3yrm4sxcsrJYNdcMmpvJFrAT5NMtir5LLJZZCHCMN5ZKsX1SNuCysmlSm2dOmrMewhWz0i50a+tp4yz6dpJ+pp4S75R8pWa7otcPJ9K6NY5aGGX4O3GuHON+1yjVKUFmSXC+SnSauOoTjJbbF3ibJpazSOUvX0/ttXPHk05t0Gro9Wr47Ze2yPdfJtADEpKMW5PCXdiUlGLlJ4S7s5tk7OoW+nVmNMXy/kDY0+rlqNRKMIfyor8zOH9aRb0Lf7HpKaoU1qEFhL/AOnM+o6Y2dNnleCX4vH6+RLuTF8Nt00vDIHmr1pxfJsVXbeDVQCt+WJrK7mzoZ7W4s51FmGss26XizcuxKjfsZZpfzlfdIu0q95zrTq08Q4E2yEJYRic2ahUJybfYlBN90VubT7GY2Sl4INuNccE1GKWDXhKXks3PBqIzJQXcq3x3bWuPDMyeXyWRrhYsN4NRKsrrW3LZVbYq0ym+/8ADJwk8rwc2Wrs1TcK1wLEl1jVXTts2wZsaSlxjmfcxp9M4LdNcl071BNIQvS719uIx7m7TPsu5ytNXLUWcJ9+53dNpPTSzyzVSRvaaMVFPybG7goqWEWszq4NmYsiYJouU0S4ZR5LIyWCpiY3MwmmCpjLZr3WbEy2bwjR1U/awOR1fXtQcU+Ty03K2xyZ1OqzzYznQlGJG4xGGCTISms8Fc7cclnEtbCTZZGvnlnNlrti4fJRPqUvMzcjGuzKMezK3Xg0dLr1c9s3z4ZfO+UZJS+5cZ1Y62Vy9rLVepLBVJ754XcmLqUZSbwixyUWlnL8mcKEcJ8/JrT4fcYS67XTtatPOLzwet0eohqas5PnULWn3Ox0jqcqbEnLgzjWvTa7pVdybisM85rum2U53Lg9lprVdTGaZDVUV3QaayyGvk/UKHCeUjWWZQ7Hrut6CupSaR5SeoVc3FQCtaXD5RKuDlJFqs3y/IbNcYRWcclRU4bUVqPJstpsg4kEq4tNYO3pIx9NHIqWOTo6X1J4jBNssiWrXT6mrhFLyfROlUenooL9jz3ROjTnbG66OMc8nrYRUIqK7I7cZjjyupAA0w0tZpG5evRxaucLyWaPVfiK2pLE4fmRsSkoxcpPCXdlGm1Fd8rHXBrHeWPzAalk7Nfc6qsxpi+X8nQpqhTWoQWEv/pTpdTTa5QhHZJP8rWDZAGr1Gn1tHOL+DaMSipRcX2YHxvqmn9HW2R57s1Np676t6a673bFcHl3A8/KZXq43YowZ25LFDkvhUmZbUV1vKN6mPBGNaRdAlF8E0jao45KK+UXweDFVtxlwTwmiiEuC2E15Az6aZLEYrgTnGMTVdjlLgqL97bwi2OcFdcMcstlOEYgVzckamo1rpWF3I6vW7OEzVpj+JnmRURdl+qsT5wb9EFTy1yzapprhBJIptWZYRqM1mWobW2K7ma9FK3mQphskt6OjCaiuexYfqzTQhpoGxHU7nwam+EvJtaeEW+ESq2KrJSfJteCuMYpdiWTNWMkWYciO4QTyY3EdxjJpF0ZlilwayeCcZlRK18HL1s8RfJ0py4OP1J+yQV5jqNy3SOS71u7m5rXmcjhamUoz4LIuujK9Lya92pyuGaDtk/JXOcjUjNrF103J8mvKUpeScn5ZW5YRpitzSTa4ydmm9WR9O3v4Z53TSbsR14QlZhRXJWW3GU4XbPL7F07lVxHmb7s0HXNXqDn7vnJmcZ1TxP7/JFbauk+7MSsNR248lNmox5Ia3lYWwucXlM4/wCL/cnDV88MYsr6T9NdT9atVSfKO/N88Hzj6d1Tr1cOe59BU8wi/wBjFjWuP1ujfCTxzg8BrdM46h8eT6Vr8OtuXweI6i4u54Xkxq65ldTRcoN8FlcMsvVfwaWKo6fjkzKj4N2mG7hl1Wld1sYxXkTtOXTHR+jW6y5cPYe56f0PT6WKzFNou6PooaXSxxHDwdE7yPPy5bUYwjBYisIkAaZDEmoxcpPCXdsSajFtvCXdnNsnZr7vTqzGmL5fyAsss6hb6dWY0x7v5OhTVCmtQgsJf/RTVCmtQgsJf/SYGlrNI5S9ej22rnC8k9Hq1fHbLixd18m0aWs0jlL16OLFzx5A3Qauj1avjtlxZHujaA0ep6CGtolGSWcHzvqvSbdHbL2vafUjV1mhp1UGpxWWY5cdb48sfJNrUuUWxwl+56Tq303bCxzo7fBwL9LdRJqyDWP2OPpY7TnKhu4JQayUSlhEqm3IWNytuM3GJKFryVTMRlhnKtR1K+Y5LYrk19PP2o2FLAVZKO5GI0xjyZi8lijwVEZSSRqam6MY/uT1GVwjVWmna+XwEabjK6z9joaaHpR4MqhQ4Jpc4Rqds3pN2Tlwjd02lajunyyOm0+xbpLk2HclwW3Ookm90kq9ji4mtlxlsl+XwzZzv7F0NPGyGJr/ACJVsQo0qeH3N6EI14NSqx6WXp2P2+GVa7qVdKzuQpO3V9RY4I+svJ5aXX28qJiHXHu9xitR6l2ZG7g8/DrlLeG8G3X1KuyPtkvuI1jp7ySkcp6vnhltWrT8mmcdHcZTKI2bllMy7MLuDFtkuDm655qkbFlpp3vdF5ZdR5DXNq2RzbKlYzt9Vow3JHFlLazUqNOdWyRZGiNkee5ctsnySjBJ8G5Wa5ltEoywuURelbWcHY9KL5aMekpyUYrksZrn6XRt2JRXJ1pShpa9keZvuxOcNLXthhzfdnPuuznnLKyzKfubzybdNsb4elb38M5Lm89zKsfyQrZ1UZUz2y7eH8nPum2dKq+Goh6N/f8A8ZHP1VctPZtn/h/IRQky+hclEZZZv6apuOcMNR1ejz26qtZ8n0ql/wAiLz4PAfT2hnfq4ycHtXk93lV1qK8I51uRVrJZrab4PK67RqU3KDO9rb/a4nFtyp7k/wDBitY50a5weGjYrXJc2pPlEoQWeAvxZUlg6PR69+sSwaMODu/Tlalbua8nTh3WPJenqoLEIr9iQB3eYAAEZwjZBwksprDMVVQqgoVxwiYAAAAAAKlRUrvWUcT+S0AAAAMOKl3SZoa3pWn1UGnBJs6AA+X9d6W9BqHhexs51P5z6L9SaGu/Ryk1yuzPn9cNtrXwzjz6ejxXVk0QUeSyRhHnrtG3Q+DZTWDQrngvVvgFbUZpG1VNY7GhW8s3ql7SozOtTZHEa0XKJr3ReQiMsPsW0VJS3NcldVbbyzeqryyxUJubWI9ij07Nx1Y0JosVMIxbZUxq6avEU2Tt1MKc7mka2t19emhLDR47qnW52uUYMNOt1jr1cE4qSeDzFnVLNXqFFSeGc3U2WW5cmS6ZFLUJzNydMvQwjsqyak3OU8RNyycdiUWjY6bpVdPLRitRxL3dDyy7S626tLMmd/qXTI+k5RR5ydDhJp+CNOlHqlmO5vaXqLf5meeg1nDNmuWWoplR7DS6z1I+1ls9XteGyno2ixpVOXkzrNP3An+Ki/JCy3KNF0TispkPVlGL3BmsayPqRaPP6ulwbOxZfnszR1XvizSY4zk0yUbMPlmLa3Fsok2jcYrdWoWMGVe4vdB4ZzHORJWtI052tm6x8tvLZpSm2ycp5RWlllNFkkiSSMcBNTUcrK7lGplfdhTzJR7GzXJIu9rWcEVoUUybTa7Hrfpimu2TjbBNHCjFOS2o9T9O0Ov3vglrcj01NVGmilVBRyRvvST5K525Xc5usub4ycrW4q1VkptuJrVyz+Yz6mFhmVh9iKxJLPCMx9pnKSMNpgWV8y4PY9B0/p0KTXc8x0mn19RFY8nu9NUqqYxSxwdvFHHy1aADq4gAAAAAAAAAAAAAAAAAA5/Wv9jL+x88UP5k3jyz6J1hZ0cjxEqcQnL9zj5XfxObNe4imXSwyvasnmdyPctXHLIwXJJmkrZ0stzOvTXmKZydHXmR39MkopYKzVcovGDXnB+Tfug8ZSNGxtdwRhPabGmsUpYNNyLdI8WcBp2G1GGTidZ6stLU8Pk6tsv5P+Dx3XK7LrGsPBSONqeoXayxpt4IV6Pc8vnJZXpnW+Vg3KZxguWix0jUXS1LuRn0t1819zpR1dS8mZayp8Iq5HMrqsjNKeT03SdkEsvBwpWKU8o2IavYlyZXI9RqXXsabWMHlNbCH4hpdmW2dSlKOM5NGd26WWGVd+n2e5GOnpz1tcf3M22OUcGNJP0NTCx+GEx9IoSr0kIpY4OL1LWbbNqIy69CWmSjndg49l8rr98gO7Q/UgmynW0N1vairT6qMYost1kXBrIZrzeovdNjjIj68ZLuU9WluvbialEXn3M0zW3ZFS8lFlS8GZRk/wArIqFvlM3GK1rIYfYqcDbnGXlGrYnuKxYxgzjgJJ+SxVvHBUxQ85MFzql8GHRNrsDEIyL6p7uERr0ds32Ov0/psY+6ZLWpxT6bonOSnJcHpdPiqCijSqlXVHasE/XWTna68Y2rr9i7nPnfvmzGqv3RwjXh8mSth8hNor3YDmBbuyGyjeialuaSER6H6aqctRuXKParsef+l9L6enU33PQHp4TI83O7QAGmQAAAAAAAAAAAAAAAAAAaXVFnStHktVH09M/3Z7HXLNDR5Tqy204OPldvE89jLwYawy5V4eSEocs4507y9sIklkjjBKGckg6PTkt/uPQ0yphFPhs8mr5V/lL69fNNZbNJju67VrGIo5Urm3yRnqfUXLKZTXyBc5InTYoyyaUrcGYWEV3K7lYkmxLS1TeZRTOdRbiS5OirvbwUa1/Rabo+1JM4HUuh205deWj1tdjZbKEbI4kkxq6+aS0d8X+VmPRuj/8Amz6K+nUzeXBB9M0/mtfYurr56qrsfkY9OxvG15PoH8N03PsX2Kf4Tp1PKivsDXh3prkuYsrVM28bWe+s6bQ48RRpz6ZVF8RWQsrya0skstEHXz2PTanRqMOEaK0fnBC1oVQxEnKLglLPc2rKti7GrqMqqJqRnUoSfyYsk8dzXjY0SlNsjTWvq3vLKHU49jalJkUslZsa8ZuD5RfXqYt4aMSryip1/BqM2NxKqz4Of1KEKocdxusrecs09bbK54NM2NNWPPBbC+cf3KtrNjTaaVskkNZxdTqnJ42m/Tan3iS03THF5kjZnpoUxyTVxiNqjzhGJ65R4Twa1t9cYvk5l12ZcMg7kdWpNc8m3CbwcLp0ZWTTO0/bFIzjcrMm2yzcoxNfdhldluXhMmIud3OCe7KNaCzyWpkVbBZZ0+m6X1L4tpuOTQohKdkYryex0miWm0tEmuWzpw49ufk5ZHodHRHT0RjH4LzC7Iyd3nAAAAAAAAAAAAAAAAAAAAAFOqX8pnkOuTxwew1H/bZ4fr9i9ZxRx8rt4nMjPLwZll9iit+8uUlnuc/x2/UOSXOOCeE0Sglkyqh58kJv28dzbsr8pFLreeUVGrCyxS7s2I2yxyT9JdyDgA3k4TIqsthTlkFtU+Vg6FEpNcmhCtxZu0ya4wUb9WcGxFMoo5NyK4IQj2LMEcE4oKrcG+xHY/JsYIyQVTs/Yg6032L2Q8hWhqqcs1LKFFcHVujuZTbUnEsTXCuqW55Ofq4LZj9zt6mqWXwcvUQ9rNz4z+xyWsEcllsJZKdrXcjoNZC4MpiXBRGU+Cic2mSnIqllliK52ZyUNJ84LpLBTJPJWai6U+TZ0s1TJcGup+GSUuQy7lOrUlhmp1HVra4o16bGjX1L3yGDUsk5MrlyXThhZKc8hiu90WCUMnQnzllPQK1OvBv62tVwM2rHKsnhtFa5eRP87MxjyTVbEGsFkVmSwuSmKy+D0P0/0t6y5SkuEWcdS8sjpfTXSXZKN1scf3PR9SioQoiuykbem08NPUoRWMGr1XtT/wAjvJjz26312RkwuxkqAAAAAAAAAAAAAAAAAAAw84eO/g0HPqOf+3E6AA5Gpu16g1KEV/g8j1Xe7W7Vhntda9zweY6rQ3Jto4eS9u/jjz7SbWxvJOuC7tvJJ1uNnBlRlu7GPzW/3E1EmoPwbdGmcoZwXR0z8oaY1q4zfGC6VCcexd6Mk+EWLMeGgOZOiSZH0Xg622EvBiVSawkDXLVeCUE1Lsbs9LLujENM13IahBZfYujBJlsKceCfpNEVdTJJI2YyyaccourkyK2lgzkq3GVIKuTItkcjIGSi53qS9KKaL0ZLKNGT1T/8UQzqfMUb8kVyRrUxpTjfJYcImjqtEpNuOG13R15NmnXzfZku6nxwr9Kor3RNGyupd8nptTRGUTh6zSSi20uBrWf9c9xoXlmrqJRUsVttGxZW/g07IvcXVxDIbDWPBHOSiuT5IdyThJt4M1wbeMF1mteUfcTUHjJsS07Ty1wbUNLvqyhrONGtPOCctM5PKRuabSNzw0dSvRrC4Jpjzlumlt7GjZRKLPaT0db8FUul1T8E9jGn9NqUXz2On1XtglpqIaZe01Nfdvfcza1HOcOSUFFSW/OPJFy5IOTk8IsSur0/Sw1VyhUnJ5PedN0ms0VEY1VRXByPo3pe2Cvsjy+T2h34x5+Vc/1Opfpx+xfXunWvxsYKW72myc/qvan/AJGmErZ69WSUIQ254/sR9TqX6cfsb67GQOf6nUv04/YsonrXaldCKh5NwAAAAAAAAAAAAAAAAADD7MyRm8RYGhdzN8nP1GnVuUzozWW2VOPJ5eXderj1HntR0zYnNGxpumxlVGTXdHT1kF+Gk8Fmlilpq+PA/E/WtTo4w4wX/hY/BsJImkRWjLSrwjXs0z+DrtL4MOCa7FHKr0me5atJE39iXgbQNL8KiMtIjfaItAaD0+0z6awbkoog4kVpuoxsaZt7TEoJomK1jOSx1EHFogZMpkcMygqeRkhkxuAsciL5IORGU8ICUkjRh/37DYdmTUhNetYbnxL+Jy7mrqIxksMusmals2Z1pz9VTFdkcyzTtyyjs2Lcihxj8FlHJenyYWk47HV9OPwTjXHHYumOP+HSi+BTpW5ZwdSVMcdi2muKXYaY1Xo91fKLtNp1GGMG8oLbjAjHDLqYpq08VLODblXGNeSdcVjLKNRZw0mZ0USaz3JQaa7mvLLK1ZsCLdS2k8HFuse55Z0bLdyZx9Tl2MIi5m90fSS1utjBLKzyc5LJ7f6G0kZy9WUTpxnbHO5Hs+naaOm0sYRWODbAO7zhz+q9qf8AkdA5/Ve1P/IDfXZGTC7IyAAAAAAAAAAAAAAAAAAAArueIlhVd+Ul+LPrUaCjklgz2PNXpiu6n1qZQTw2Zqq9OqMM5wsZLEyXcT4lQUSSRkAYwMGQUYwMGRgggzDRNojggg0RkizBhoNKcEsGXEdgIOJFwLTOCK13Ag4m04rBBxQGnJYI4L5R5ISiBrybK5y4L5RyUWV8BWvOTRrKW2cnnuW3KSzg0puXJNGxK39yiTya07JJkfVZFXyxgplFtmYyb7k0/kqqlHgz2LcIztRdGuyyDw0T9NElBIaJKXBOJDgSmox7lTU7Z7YmhZZl8kb9V3SZpW6n2jGbWxZcku5rSv8A3NKy9tkFJssia27L0oGlJ7m2Sak3yRaa8FxGa63ZYox7yZ9T+ldF+G0EXKOG0fPug0xu6hBSXZ5PrWlrjXp4RiuMHXhHHnVoAOjmGvq9N+IUMSxtlk2AAAAAAAAAAAAAAAAAAAAAAACm58FxRa8vBnl8a4/VIJY4MHmeiBJESSLCgMoYKjCMgIIyYZkARaMYJjANQaMYLMGMBdVuJBxL8EWiVdU4MkmiLIawyEiTlgrlIKrkVyZOTKpMghJ8lcpLHInk1pyeQrFrizUsimXyTZVJEVpWVclLjhm9JcGtNchVaRLJgMCSZkqJJgXR7CXYq9TCNe3U4TBq6dqh5NLUavKwmat+pbbWTTlbk1Izatsv5fJRKbl5MGdvHBtkUcksNGYcE5NYKivLZJLjkx25Q35ZFjr/AEzXKXUo4R9Vq4riv2PFfRegi/5zXPc9v2O3GdPPzvYADTIAAAAAAAAAAMSlGEXKTwl3ZiE42RUoSUk/KMyipxcZLKawzmtWdOuysyok/sB0wRrnGyCnB5TJAADT1mr9L+VV7rZf/ANn1a/V9Pet+M4JmpotJ6WbbXm2Xf8AY2wAAAGvZ+Y2CizuY8nxvh9Q8GDPgwcHZgkjBlAZAMlRgygAMgxkZCMkFbB2OtSW9d0Syaer0zk/WpeLF8eRCtwGtpdUr47ZcWLuvk2MggYbDZVbbGqDnN4SI0zZZGuO6bSXyyEpJpNdmaUVPWWb7OKl2RuSwlhdkLFnamUiuUiyaKJ5QVlyI4yyLlwZrllkGZ15Rq2VNZ4OjlYKppNcAcqXBrzlydG6nuznXLDIqE3wa0u5ZKRTJ5IqIwZJYAjgYMkZAVWyUYM5s5SnJqKybmo3YeDn5lCe5GpGa1bW9zKucm/dUr476/zLujTcWnhnTGNIJsuxiJCCaZYpfIVFLkslVJJZWMl1dcYx9Szj4RRbdKU8+PATUXHaiNUVO2MfliU5NGx02r1tZCP7k/V/H0v6Y0yp6fFr4O2afS6fR0UI/sbh3jz36AAqAAAAAAAAAAAEZwjOLjNZT7okAOY1Z067KzKiT+x0a7I2QU4PKYnCM4OM0nF90UaXTLTuajY3GXZfAENZq/S/lVe61/8AwaPSel/Nt91r+fBLTaOFU5WSl6k2+78G0AAAAAAYk8IofLLLHwVI5c66cJ0GCRg5uiJkNGAqQMGQMmGDDCGRkiyLZFxPJjJW5EXZ+4XFOrobl61LxYuePJLT6xWx2y4sXdfJGVuPJq2wg7FZGW2SfP7jT1/jft1EKoOUnwaKc9ZZvsyq12RTfOuycXOzheDP46mPtTSSG4uOipJRwuEjG/JpLVQl2kicbk/JnVxe2QlhkJT/AHI7uSjLhkio7SaYn2CIOzHBJTTXc1p8Mole4PuNG3qHiPBy74t5Zf67seMkbsKJFjmSzkjgukuclbI0wkDJlICODDiWpGJYKjVtjmJoXVSz2OthMz6MZLsWJXBjvrllIxdV6y31rEvKOzZpo47HPtg6pZiblc7HPinnD4NiupQXqWdl2RidsVbvcP8ABXZqfUlysL4Khda5yy+3hFEpkrXFrhlHLDWJKTfk6vQk31CBzIVs9H9K6dW62La7McfqX4+k6XjTV/2LiNcdsFFeCR3ecAAAAAAAAAAAAAADT1mr9L+VV7rX8eAGt1fpfyqvda/jwS0WmlTCUrG3ZPuR0ek9L+bb7rZfPg3AOY1Z0+7csyok/sdGuyNkFODzFicIzg4zSafdHOas6ddlZlRJ/YDpgjXONkFODzFkgABh9gK7GQQk8sI89u13kyAMmCDDIskyLDQMmBkKlkNkcmHIhhJlUpCTK5BWJTNe63C7k5vBrXJbXKT4IrWu1iimc67U2WPPPHY34aSWolvksQXYu/BwX/ii/E+uE3dN5eStwm3nLyd96VLsjXu0n/lBcknfTV67cqMrYvuyxau2Hlm3GEZrDXuRCdK+CWLLKjV1KSfvOhTrIzWUzmPTJ9zD/lrbFgx3I3xfky7U/JwoWzj5bLo6mS7jUx0bJmldLL7kJ6njuas78k0bEJ4sSyS1VnZGlG7NiLNS9zRFY3cAjFcFiQEUiaRlLBiTKDMYyETjEqMKCJ7eDKRngIrlHKNG6uPLfg3pPLxE171iDWDpOmL24l88W78corurjqIb6+JeUS1dc3J7UNJp7VLI1M/jnuLTw8ltcG/B1LdD6j3JYfkz+E9OPYLGlCJ7v6P6fsq9WS7nk9Lp/U1EI4zln0vpGnWn0UEljKN8J+seS5Mb4AOriAAAAAAAAAAAAAIW73VJV4344ya+j0fot2Wvda/PwbYAAAARnCM4OM1lPuiQA09NprdPqJbZJ0vw+5uAACM3hEiqx+CcrkWTtX5MowjJ53cMAwAZgNmCNDI5DItlBsi5BsiwDZCWfBNQbLFAiqVVu7mvZpJTvzNr012SN9ohIfBVtSWEsJEJLksbIMiqZIqlFs2JclckF1z7qG3uhxIjKHHPc3ZIomkVGlNPBruPPJuW48FLrbM4uqVFEZ4ROcJeCmcJDF1XPlkHHgnhpmcZJghCHvRsWrsVxTTRO18IYMRwkT3LBSm3wZ2sYJ7xnJhQZONbyAiWIzGplsayoraeCuW7wbirMbEVmtaMXgw6t3c2sJdkQf7F1GlLRwby0WV6eKeFE2o1uRfCrbyFa34aLXY1tTSoVvdj9jqTajHLOH1LU7ntTKmL+gaf1+oprsj6FCO2CS8I8l9H6Z4dj/uevO/CdOHO7QAGmAAAAAAAAAAAAAAAAAAAAAAAAEZPCKG8snbLwVnHny7x14cWUZMGTm2wYZlmGiqizDJ4MNDDVbyQeS5xMbQqrYyUYE+wyA7DJhmArDZBkmRYEGQaLGRZBW0VSLpFckFa88lEzalEqnADW25M7MIs2YZlpFFPpZ8EZaf9jajHLLHHgGuVLTe7OCEtNnsdOUUVusmGueqGjEqn8HQ9P9jKqJhrlxoeS6NJv+ivgx6eBhrWjSiaqSLtuDKWBhqGzCMNYJuSK2+Qg2VyZJp+BGptgQ9zfBdVS3yy2FSj4LkuAIKtJcEZcFr4Ne6ajBtlRp6+5QrayeZuk52N58m/1LUuU2kc1cyEK+g/SSxpF/Y9EcP6YjjRRePB3D08fjzX6AAqAAAAAAAAAAAAAAAAAAAAAARm8IkUXS8E5XI1xm1BvLyZIpk0ea9u3xgyAUBgGSoi3hZbwkO6yuxTr/8AZz/wS0n+0q/4jDU2YJMiRphmDLZFsisNmMhkWVRmAyLfACRBsPuRbJQZXJk2+CqXciotkGsk8GSipxI7S1mMFRGKwjDkTxwQ28gRfclgyoMkoAYUSSinleScYlGnX/U2g1NxIuJfJFbQFLiiEi9xIuGSDWaZhQybSqJqpIDXhWWKBdswNoEFFjsT7EJSWCorssSRxuo3yw1Fm7q7dqZ57Vahym0SkatrcpcmaY/zY5+TDeWZqf8AOh/cRa+m9Cio9Phj4Okc/on/APnwOgemfHlv0ABUAAAMOSjjLSzxyZOf1XtT/wAgOgDC7GQAAAAAAAAAAAAACM5bY5NWTy8mNZdte1EYPMUcvJfx14T9Tj3JpkMGUjlHSppmSKMo0yGTAA1+oP8A6Of+Cekf/SVf8SHUP9pP/BnSP/pK/wDiX8P1a2RyZZgy0izDMswyKizBkxgqsMg2WNEGkRVcmQyWSRHaiCDK33L2kVSXIETDZLHBW85KMpZM4JQXBYolRUo8GfTLlEyogVKslsLMDARDaaunX/VWm6aen/3dxYlbDRBosZjBFVbTKgWYQyFQxgYJDAGGiLJshJkxFc2a889y98mtqp7IPAVyepWuKZxG9zyzb19znNpmnHuBLYsFalsti/hlreEa0nvsSXyIV9Q+nrlZoIJfB1jg/StcoaKO74O8emfHlv0ABUAAAOf1XtT/AMjoHP6r2p/5Ab67IyYXZGQAAAAAAAAAAAB9gQtko1tsDlaxt6hf3L6n7Ua6astbNqC4PNyvb0cZ0sXckkYXclkDDwll9ka/4/T/ANb+xsvkpenof/5Q+xYiH4/T/wBb+xj8fp/6n9if4aj9KP2MfhqP0o/YdGVXOyvWVSqqn7sZ5QV9WmhGqc/dFeEZvUdPROdUIxl84FcIX1QsshFya74Co/jqP639h+O0/wDU/sWfhqf0o/Yfhqf0o/YdL2qWtobxvf2L2Q/D0p5VcfsTZlYwRyZIyDTDkQbyH3MPgKy2YZhmOQiMskUnktxwYwUR2kXDkvjEztCKoR4LNuCcY4JYAqUSFl1VT2zlh/2NjBGdVc+ZQi3+6CVrfi6P6n9jH4un+p/Yuenp/Tj9jD09P6cfsXpO1P4un+p/YgoKiyy2UltkX+hUnlVx+xTXN23WVzScV2WAH4un+p/Yfiqf6n9iz0Kv04/YehV+nH7Dpe1X4qn+p/YsrnCyO6DyjKoq/Tj9iajGCxGKS/YdHbGDDJZMEVFog8E5MqmwjE8JHK6jeowfJt6ixxizzmvulKbWQrTvlvm2iD9scsko+TU1luFhMghfqPCY0LctRDPPJpZ3SN7QLbdF/DLEr6z0OKj0+GDonM6FYp6CGPg6Z6J8ea/QhZZGqDnN4ivJMxKMZxcZJNPwyo1v4hpv639mP4hpv639mWfhdP8Aow+w/C6f9GH2Ar/iGm/rf2ZG6ENfCEqprEJc5Rd+F0/6MPsUauz8JGtURjFSlzwBZPXaeEnBzeVw+DH8Q039b+zLZaemb3Sqg2+7wY/C6f8ARh9gK/4hpv639mSr1lFs1CE/c+2US/C6f9GH2JQophLdCuKfykBYAAAAAAAAc7qmoVdW3Pc37JKEHJ+Dy3UNQ9Rq9qfCMc+WRrjx2t3SNNZTN+HY5+ir2pM6MFwefdr0fIku5IwZNIZGQYAyYACtfX/7Sf8AglpP9rX/AGI67/aT/wAEtJ/ta/7F/E/VoYMMisNmGSwYaIqDISJsjgKgkGiYwUV4MpE8BICODGOSwbQjEUSxkJGQCQYQYGAABhojgkMEFbNPTL/q7v8A+8m80aWm/wB3d/8A3k1ErZwMEsDBFRwYZJmGBAwZbIuQEZMqmycmamqvVcWGWj1C9Ri0cKxqUsl+tvlZNmnnky1Fd9qhHC7nKum5y5NvVvLZovuBKqPuOjQsLJo08s6FPCKPoX0pcp6VRb7I9CeA+mdf+H1Krk+Gz3tc1OCkuzPRxux5ucypAA0yAAAc/qvan/kdA5/Ve1P/ACA312RkwuyMgAAAAAAAAACjVXxoqcpPAGh1nWxqqcIvlnA0sXOzc/LIa3UPUaptvhM29FFZR5efL2r1ePjkdbTRxFG3HsUU9kbEexmQrIANoGDJgKDAMga+ui3pZ4WSWlTWmrTWHtLQVGAARWMmGwwRUGYJNGMBWMDAZkpWMAyAjBJGDKIGBgyYIGAABgwZAGDBlkSgammi1q7m08G2YLKUMBmAMMiyZFoIgyLwibRXJAVWS44Ofqa3OLbOk4eWcnqeqVcXFAcPVpQm1k0LLMIuvtcpNtmjbLJlYpunllW3JKUcskoFEqY4ZuQZrw4L4Mg3NPP05qafKPoHQOoR1GmUW+UfOYvHZna+nNb6GrUZPCbN+Pkx5OPT6KCFc1OtSXlEz0POAAAaHVIykqdqb93g3wBhdjIAAAAAAAAAEZyUY5fY8v1zXOybhB8I6nWtX6NLinhnkbZynNts4eXnnTv4uG9s18vLOtoWso5Naydjp8FhPBxjtXZq7I2F2KKu3YuTNxipYMYG4bioYGBkyBEEsGMARMmTAGAAwrAMNgKGGAQRaMmWggMYGCWBgCOAZZgAAAAAAwDIYEGYJNGMAYwYwZAEWCTI4KgYMkWwISImW0uTU1WqjXFkFes1kaotJ8nmdbqHbJtk9drPUseGcq+/hoLiq2zlms5NszJ5ZEisphSMYG1hFkZFqlwVRRalgKQseeTa09rrtU08NM1H3La+RCvp3QNYtTo485eDrnhPpXX+laqpS4Z7qLUopryenjdjy85lZABpkAAAAAAAAAAArvsVVTk/Bm1SdUlXLbJrhnn+odRthTKi7ixcZ+Scrk1ZNrm9V1rvua8JnPik3yYsllt/IpWZ8nht2vbJkyN7TVRkztaWpRijnaOrnJ1lKNVW6TwjcTk2IomjU0k7rrHY+KvC+TcRrMYDIMlBGcmAEZyMmABkGAFCLJGAMbRgkAImDLGArGAkSwad9t2nv3v3VPx8FiWtsPsYhONkFKDymZfYioswZZggyYNS7UzssVOm7+ZG3FNRSk8vHLBowZGAMGGSDAgYJMxgowNuTOABHAMmGERbRXKS5MyNe2aim2wirU3KEHyed6lrc5SZf1PWpZimed1F+6TyZrUiFtjbbyUWPKE3lcGKXH1MWLKYjSrlssUGTtodcsx5i+zMRyEYxhkscEsIdgMRWCWS2qve8ePLFkYKSUF27sYb+IOOSUU4mYLLLHHKAu0tzouhbF9mfSujar8To4yzl4PmUY4ij2f0jqJShsbOvjrl5J+vVAA7OAAAAAAAAAAAMSe2LfweN65ardS0u6PS9U1Dp08mvg8XqLHZY5PycPLyzp28XHe2vLJbSvciGCyp4lycMl7d5107GknGuG6T4Rt01z1k1OzKrXZfJzdHH1prdxFeD0FGFFJLCR0nTF7WwSikksJeCQRkowEjJkDAAAwDJgDJgGGBnIZhIdgMoNkXIxkCRkiiXgBkhOKnFxksp+CQCue1PQ25WZUyf2N6E42QUoPKZmUIzi4yWUzRjXbpL8QTnVJ+PBfrPxumlqL5Wz9DT8t92izWStbjVVF+7vIs0+njRDC5k+7C3vpjT6eNEMLmT7suBgzVZBjJhyAkCGRkCTMGMmMlQZjJkYAxkjImVWSUSCq2WyOWcXqWu2xaTL+qatwg8M8rrNU5t8hcV6u5zbeTnSy2TnNtkcEaRSZNQJRWCRBdVKKjsnzF/wDwhdVs5XMWQayXUzxHZPmLNbvVS9dxqvOTYqqdn9vLIzrj6qipcPybO5KGyvt8k/8Aqb/GJyUFsr/yyMYcGdpZXz3JbrUmIQjgtWMGdpKEeSaIpc4O/wDTFrq1e04cotSRvdLudOshLwb4XtjlNj6QuwKtNNWURlnwWnqeUAAAAAAAAAAHD69biG08xNcnoPqFvx8nn5rHc8fl28nr8XXFGOMcltMFOXJTHl/sbmng5SWEJka7rf6coRnss9r8HagkjmQ0vqV/El2ZsaW+Sl6N/E12b8m8l+MfPrfRkgskuQJAxz8DkDIMcmcMAYGGOQAMGcAYciPLZLH7DH7FGNowS5MYICRkBZAGDLz8GAoas9U5XqqmKlz7mQ1F8rZ+hp+W+7NjT6eNEMLmT7suM7qvVXzonF7M1vuy+Eo2QUoPKZmUFOLjJZTNBqzQ25WZUyf2C7jfZgQnGyClB5TMYwzK6NEWiQeQIhmcMzgCGGME8GMFRgDBnHkFQk8LJzNfqlCL5NzWW+nU3k8d1PXOU5LLJSRDqGtdk2s8HGunmQttlOXkracn2I0g8tkopk1VJLsTjGS8MKr5M4ZZteeUZUSCMYtl1dbnx4+TNVbk/wBiyUtvsgv7ssn7UtvyK/Rgp4zwWOrY+Oxjll9XEcS7DqncVKGSarwW7cPjsS7oxemp2hHHYLiRnb7iUo8gJRyRTcGpLwWLtyV2dmIY9v8ATvUIajTqDfKO4fNOh6yWm1yjnhs+j0WK2mMl5R6+F2PJzmVYADbAAAAAAAADXv0dGo/7scmnZ0HQWPMoz/xI6gJ6xdscr/T3T/6bP/Ytq6Po6nmCn/mR0AT04/xffl/VC0tS7J/cjdoaLsOcXleUzZBfWJbarjTCMUll48tmfTiTAyG1D04j04kwMhtQ9OI9OJMDIbUPTiPTiTAyG1D0o/A9KP7kwMhtQ9OI9OJMDIbUPTiPTj8EwMhtQ9OPwPTj8EwMhtQ9OPwRs08JwcXuSfwy0DIbWvToqKE/TT58t8lnpQ/f7lgGQ2oKqK+TE6a5xcZRyn4LAMhta9Ojpozs3Yfhst9KHwTAyG1X6MPgelD4LAMhtV+jD4HpQ+CwDIbVfow+B6MPgsAyG1X6MPgejD4LAMhta1uhoujicW1/c0p/TvTZvMqpf+x1gMh7Vxv9MdK/Rl/7Gf8ATPS/0Zf+x2APWL7cv65P+nOmfov7j/TnTP0X9zrAnrP4e1/rkf6c6Z+i/uP9OdM/Rf3OuB6z+HtXIX0501P/ALc//Yz/AKd6Z+i/udYF9YntXK/09039J/cz/AOnfpP7nUBPWfxfa/1yn9P9Obz6cl/aRP8AgXT/ANJ/c6QHrE9q5v8AAun/AKT+4/geg/Sf3OkB68f4vty/rm/wPQfpP7mH0Hp771P7nTA9Z/D2rlw6B06E1KNTTX7nSrrjXBRgsJEgaxnQAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAf/2Q=="));
}

struct {
    bool ActivateAll = false;
    bool loginIndia = false;
    bool SilentGhostPullV2_Enable = false;
    bool mode360v2 = false;
    bool teleCombo = false;
} MasterBool;

struct {
    bool Aimkillsend = false;
    bool AimkillTake = false;
    bool backFakeFix = false;
    bool downkill = false;
    bool downkillv2 = false;
    float aimbotFOV = 0.0f;
} pAimbotPlayer;

struct {
    bool espLine = false;
    bool espBox = false;
    bool espHealth = false;
    bool espDrawFov = false;
    Color espColor = Color::White();
    bool espNickName = false;
} pEspPlayer;

using namespace std;



extern "C"
JNIEXPORT void JNICALL
Java_com_kanishkcheat_Menu_Init(JNIEnv *env, jclass thiz, jobject context) {
    startClient();
}

float fovRadius = 104;

extern "C"
JNIEXPORT void JNICALL
Java_com_kanishkcheat_Menu_Functions(JNIEnv *env, jclass clazz) {
    // Anti extraction / skip-login native guard: the cheat UI must never init
    // unless a real KeyAuth success mirrored the session token into native.
    if (!ngSessionActive()) {
        LOGE("BLOCKED: native menu without active session");
        return;
    }

    Widget widget = Widget(env);

    widget.Tab(OBFUSCATE("AIMBOT"));

    widget.Switch(OBFUSCATE("Enable Functions"), 102);
    widget.FloatingSwitch(OBFUSCATE("Silent kill"), OBFUSCATE("pull"), 777781);
    widget.Switch(OBFUSCATE("Mode 360"), 59926);
    widget.Switch(OBFUSCATE("Login India 400"), 5020);
    widget.Switch(OBFUSCATE("Teleport"), 59910);

    widget.Switch(OBFUSCATE("Enable Keybind"), 6000);
    widget.Switch(OBFUSCATE("Clear Keybinds"), 6001);
}


extern "C"
JNIEXPORT void JNICALL
Java_com_kanishkcheat_Menu_ChangesID(JNIEnv *env, jclass clazz, jint id, jint value) {
    switch (id) {
        // ESP Toggles
        case 1:
            pEspPlayer.espLine = (value == 1);
            break;
        case 2:
            pEspPlayer.espBox = (value == 1);
            break;
        case 3:
            pEspPlayer.espHealth = (value == 1);
            break;
        case 9:
            pEspPlayer.espNickName = (value == 1);
            break;
        case 16:
            pEspPlayer.espDrawFov = (value == 1);
            break;

        // Settings
        case 5020:
            MasterBool.loginIndia = (value == 1);
            SendFeatuere(5020, MasterBool.loginIndia);
            break;

        // Aimbot & AimKill
        case 102:
            MasterBool.ActivateAll = (value == 1);
            SendFeatuere(3, MasterBool.ActivateAll);
            break;
        case 104:
            pAimbotPlayer.aimbotFOV = (float)value;
            SendFOV(104, (float)value);
            break;
       
        case 1305:
            pAimbotPlayer.backFakeFix = (value == 1);
            SendFeatuere(1305, pAimbotPlayer.backFakeFix);
            break;
        case 59926:
            MasterBool.mode360v2 = (value == 1);
            SendFeatuere(59926, MasterBool.mode360v2);
            break;
        case 1045:
            pAimbotPlayer.downkill = (value == 1);
            SendFeatuere(1045, pAimbotPlayer.downkill);
            break;

        case 1047:
            pAimbotPlayer.downkillv2 = (value == 1);
            SendFeatuere(1047, pAimbotPlayer.downkillv2);
            break;

        case 777781:
            MasterBool.SilentGhostPullV2_Enable = (value == 1);
            SendFeatuere(777781, MasterBool.SilentGhostPullV2_Enable);
            break;

        case 59910:
            MasterBool.teleCombo = (value == 1);
            SendFeatuere(59910, MasterBool.teleCombo);
            break;
    }
}

struct EspDrawEntry {
    PlayerData data;
    Rect rect;
    float boxCenterX;
    float boxTopY;
    float boxH;
    bool isCaido;
    float scale;
    Color espColor;
};

static void ParseEspPlayerName(const char *raw, char *outName, size_t outNameSize) {
    if (outName && outNameSize > 0) outName[0] = '\0';
    if (raw == nullptr || raw[0] == '\0') return;

    const char *tab1 = strchr(raw, '\t');
    if (tab1 == nullptr) {
        strncpy(outName, raw, outNameSize - 1);
        outName[outNameSize - 1] = '\0';
        return;
    }

    size_t nameLen = (size_t)(tab1 - raw);
    if (nameLen > 0 && nameLen < outNameSize) {
        strncpy(outName, raw, nameLen);
        outName[nameLen] = '\0';
    }
}

extern "C"
JNIEXPORT void JNICALL
Java_com_kanishkcheat_Menu_OnDrawLoad(JNIEnv *env, jclass clazz, jobject draw_view, jobject canvas) {
    DrawView draw = DrawView(env, draw_view, canvas);

    if (draw.isValid()) {
        Response response = getData(draw.getWidth(), draw.getHeight());

        if (!response.Success) {
            return;
        }

        std::vector<EspDrawEntry> entries;

        const int playerCount = std::max(0, std::min(response.PlayerCount, maxplayerCount));
        for (int i = 0; i < playerCount; ++i) {
            PlayerData data = response.Players[i];
            Vector3 HeadLoc = data.headPosition;
            Vector3 PesLoc = data.bottomPlayerPosition;

            if (!std::isfinite(data.distance) || data.distance <= 0 || data.distance > 280) continue;
            if (!std::isfinite(data.health) || data.health <= 0) continue;
            if (!std::isfinite(HeadLoc.X) || !std::isfinite(HeadLoc.Y) || !std::isfinite(HeadLoc.Z)
                || !std::isfinite(PesLoc.X) || !std::isfinite(PesLoc.Y) || !std::isfinite(PesLoc.Z)) continue;
            if (HeadLoc.Z < 0.1f || PesLoc.Z < 0.1f) continue;

            float distance = data.distance;
            float scale = std::max(0.5f, std::min(1.0f, 500.0f / distance));
            float headScreenY = draw.getHeight() - HeadLoc.Y;
            float rootScreenY = draw.getHeight() - PesLoc.Y;
            float rawHeight = fabsf(rootScreenY - headScreenY);
            if (rawHeight < 5.0f || rawHeight > 1000.0f) continue;

            float boxHeight = rawHeight * 1.12f;
            float boxWidth = rawHeight * 0.58f;
            float boxY = std::min(headScreenY, rootScreenY) - (rawHeight * 0.06f);
            float boxCenterX = (HeadLoc.X + PesLoc.X) * 0.5f;
            float boxX = boxCenterX - (boxWidth * 0.5f);
            float boxW = boxWidth;
            float boxH = boxHeight;

            if (boxX >= draw.getWidth() || boxX + boxW <= 0
                || boxY >= draw.getHeight() || boxY + boxH <= 0) continue;

            EspDrawEntry entry;
            entry.data = data;
            entry.rect = Rect(boxX, boxY, boxW, boxH);
            entry.boxCenterX = boxCenterX;
            entry.boxTopY = boxY;
            entry.boxH = boxH;
            entry.isCaido = data.isDieing;
            entry.scale = scale;
            entry.espColor = entry.isCaido ? Color::Red() : pEspPlayer.espColor;
            entries.push_back(entry);
        }

        if (pEspPlayer.espDrawFov) {
            float screenW = (float)draw.getWidth();
            float screenH = (float)draw.getHeight();
            float centerX = screenW / 2.0f;
            float centerY = screenH / 2.0f;
            float fullScreenRadius = std::max(screenW, screenH) / 2.0f;

            float currentFov = pAimbotPlayer.aimbotFOV;
            if (currentFov <= 360.0f || currentFov <= 0.0f) {
                currentFov = fullScreenRadius;
                pAimbotPlayer.aimbotFOV = fullScreenRadius;
                SendFOV(104, (int)fullScreenRadius);
            }
            draw.DrawCircle(pEspPlayer.espColor, 1.5f, Vector2(centerX, centerY), currentFov);
        }

        for (const EspDrawEntry &entry : entries) {
            const PlayerData &data = entry.data;
            const Rect &PlayerRect = entry.rect;
            const float boxCenterX = entry.boxCenterX;
            const float boxTopY = entry.boxTopY;
            const float boxH = entry.boxH;
            const float boxY = PlayerRect.y;
            const float boxW = PlayerRect.w;
            const bool IsCaido = entry.isCaido;
            const float scale = entry.scale;
            Color espColor = entry.espColor;

            if (pEspPlayer.espBox) {
                draw.DrawCornerBox(espColor, 1.0f, PlayerRect, 2, 2);
            }

            char playerNameBuf[256] = {0};
            ParseEspPlayerName(data.name, playerNameBuf, sizeof(playerNameBuf));

            const float healthBarGap = 3.0f;
            const float healthBarW = std::max(6.0f, 7.0f * scale);

            if (pEspPlayer.espHealth && !IsCaido) {
                float healthBarX = PlayerRect.x - healthBarGap - healthBarW;
                draw.DrawVerticalHealthBar(Vector2(healthBarX, boxY), boxH, 200.0f, data.health);
            }

            float fontSize = 11.0f * scale;
            if (pEspPlayer.espNickName && !IsCaido && playerNameBuf[0] != '\0') {
                float namePosY = boxY + boxH + 12.0f * scale;
                draw.DrawTextCenter(Color(0, 0, 0, 255), playerNameBuf, boxCenterX, namePosY - 1.f, fontSize);
                draw.DrawTextCenter(Color(0, 0, 0, 255), playerNameBuf, boxCenterX, namePosY + 1.f, fontSize);
                draw.DrawTextCenter(Color(255, 255, 255, 255), playerNameBuf, boxCenterX, namePosY, fontSize);
            }

            if (pEspPlayer.espLine) {
                Vector2 lineStart(draw.getWidth() / 2.0f, 0.0f);
                Vector2 lineEnd(boxCenterX, boxTopY);
                draw.DrawLine(espColor, 1.0f, lineStart, lineEnd);
            }
        }
    }
}
